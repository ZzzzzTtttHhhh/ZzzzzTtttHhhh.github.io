#include "show.h"
  /**************************************************************************
���ߣ�ƽ��С��֮��
�ҵ��Ա�С�꣺http://shop114407458.taobao.com/
**************************************************************************/
unsigned char i;          //��������
unsigned char Send_Count; //������Ҫ���͵����ݸ���
float Vol;

/**************************************************************************
�������ܣ�OLED��ʾ
��ڲ�������
����  ֵ����
**************************************************************************/
void oled_show(void)
{
	float Pitch_OLED;
	float Roll_OLED;
  float Yaw_OLED;

    /* MPU6050����ϵת����PCB����ϵ */
    Pitch_OLED = -Pitch;
    Roll_OLED  = -Roll;
    Yaw_OLED   =  Yaw;

    OLED_ShowString(0, 0,  "P:");
    OLED_ShowString(0, 20, "R:");
    OLED_ShowString(0, 40, "Y:");

    if(Pitch_OLED < 0)
    {
        OLED_ShowString(18, 0, "-");
        OLED_ShowNumber(26, 0, (u32)(-Pitch_OLED), 3, 12);
    }
    else
    {
        OLED_ShowString(18, 0, " ");
        OLED_ShowNumber(26, 0, (u32)Pitch_OLED, 3, 12);
    }

    if(Roll_OLED < 0)
    {
        OLED_ShowString(18, 20, "-");
        OLED_ShowNumber(26, 20, (u32)(-Roll_OLED), 3, 12);
    }
    else
    {
        OLED_ShowString(18, 20, " ");
        OLED_ShowNumber(26, 20, (u32)Roll_OLED, 3, 12);
    }

    if(Yaw_OLED < 0)
    {
        OLED_ShowString(18, 40, "-");
        OLED_ShowNumber(26, 40, (u32)(-Yaw_OLED), 3, 12);
    }
    else
    {
        OLED_ShowString(18, 40, " ");
        OLED_ShowNumber(26, 40, (u32)Yaw_OLED, 3, 12);
    }
		//=============ˢ��=======================//
		OLED_Refresh_Gram();	
	}
