#ifndef __USARTX_H
#define __USARTX_H

#include "sys.h"

#define UART4_RX_BUFFER_SIZE 128

extern volatile u8 Usart4_Receive;
extern volatile u8 UART4_RxFrameReady;
extern volatile char UART4_RxFrame[UART4_RX_BUFFER_SIZE];

void uart4_init(u32 bound);
void UART4_SendByte(u8 data);
void UART4_SendString(const char *str);
void UART4_SendAngles(float pitch, float roll, float yaw);
u16 UART4_ReadFrame(char *buffer, u16 buffer_size);
void UART4_IRQHandler(void);
#endif
