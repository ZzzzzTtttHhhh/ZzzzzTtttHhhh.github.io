#include "stm32f4xx.h"
#include "sys.h"
#include "usartx.h"
u8 Way_Angle = 1; 
u8 Flag_Qian, Flag_Hou, Flag_Left, Flag_Right, Flag_sudu = 2;
u8 Flag_Stop = 1, Flag_Show = 0, Flag_Hover = 0;
int Encoder_Left, Encoder_Right;
int Moto1, Moto2;
float Angle_Balance, Gyro_Balance, Gyro_Turn;
float Balance_Kp = 300, Balance_Kd = 1, Velocity_Kp = 80, Velocity_Ki = 0.4;
float Zhongzhi;
u8 delay_50, delay_flag, Bi_zhang = 0, PID_Send, Flash_Send;
char PC_Receive_Buffer[UART4_RX_BUFFER_SIZE];
volatile u16 PC_Receive_Length = 0;
int main(void)
{
    delay_init(168);
    uart_init(128000);
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    LED_Init();
    OLED_Init();
    Encoder_Init_TIM2();
    Encoder_Init_TIM4();
    delay_ms(500);
    IIC_Init();
    MPU6050_initialize();
    DMP_Init();
    MiniBalance_Motor_Init();
    MiniBalance_PWM_Init(8400, 1);
    MiniBalance_EXTI_Init();
    uart4_init(9600);
    while(1)
    {
        oled_show();
        PC_Receive_Length = UART4_ReadFrame(PC_Receive_Buffer,UART4_RX_BUFFER_SIZE);
				UART4_SendAngles(Roll, Pitch, Yaw);
        delay_ms(1000);
    }
}
