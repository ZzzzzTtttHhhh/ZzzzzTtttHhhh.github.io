#include "usartx.h"

volatile u8 Usart4_Receive = 0;
volatile u8 UART4_RxFrameReady = 0;
volatile char UART4_RxFrame[UART4_RX_BUFFER_SIZE];

static volatile u16 UART4_RxIndex = 0;
static volatile u8 UART4_RxColonCount = 0;

static void UART4_HandleLegacyCommand(u8 data)
{
    /* Keep compatibility with the original MiniBalance remote-control commands. */
    if(data == 'Y') Flag_sudu = 2;
    if(data == 'X') Flag_sudu = 1;
    if(data == 'b') Flag_Hover = !Flag_Hover;

    if(data > 10)
    {
        if(data == 'Z')
            Flag_Qian = 0, Flag_Hou = 0, Flag_Left = 0, Flag_Right = 0;
        else if(data == 'A')
            Flag_Qian = 1, Flag_Hou = 0, Flag_Left = 0, Flag_Right = 0;
        else if(data == 'E')
            Flag_Qian = 0, Flag_Hou = 1, Flag_Left = 0, Flag_Right = 0;
        else if(data == 'B' || data == 'C' || data == 'D')
            Flag_Qian = 0, Flag_Hou = 0, Flag_Left = 0, Flag_Right = 1;
        else if(data == 'F' || data == 'G' || data == 'H')
            Flag_Qian = 0, Flag_Hou = 0, Flag_Left = 1, Flag_Right = 0;
    }
    else if(data < 10)
    {
        if(data == 0x00)
            Flag_Qian = 0, Flag_Hou = 0, Flag_Left = 0, Flag_Right = 0;
        else if(data == 0x01)
            Flag_Qian = 1, Flag_Hou = 0, Flag_Left = 0, Flag_Right = 0;
        else if(data == 0x05)
            Flag_Qian = 0, Flag_Hou = 1, Flag_Left = 0, Flag_Right = 0;
        else if(data == 0x02 || data == 0x03 || data == 0x04)
            Flag_Qian = 0, Flag_Hou = 0, Flag_Left = 0, Flag_Right = 1;
        else if(data == 0x06 || data == 0x07 || data == 0x08)
            Flag_Qian = 0, Flag_Hou = 0, Flag_Left = 1, Flag_Right = 0;
    }
}

static void UART4_FinishRxFrame(void)
{
    if(UART4_RxIndex == 0 || UART4_RxFrameReady)
        return;

    UART4_RxFrame[UART4_RxIndex] = '\0';
    UART4_RxFrameReady = 1;
    UART4_RxIndex = 0;
    UART4_RxColonCount = 0;
}

void uart4_init(u32 bound)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, ENABLE);

    GPIO_PinAFConfig(GPIOC, GPIO_PinSource10, GPIO_AF_UART4); /* PC10: UART4_TX */
    GPIO_PinAFConfig(GPIOC, GPIO_PinSource11, GPIO_AF_UART4); /* PC11: UART4_RX */

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10 | GPIO_Pin_11;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOC, &GPIO_InitStructure);

    USART_InitStructure.USART_BaudRate = bound;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(UART4, &USART_InitStructure);

    USART_ITConfig(UART4, USART_IT_RXNE, ENABLE);
    USART_Cmd(UART4, ENABLE);

    NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

void UART4_SendByte(u8 data)
{
    while(USART_GetFlagStatus(UART4, USART_FLAG_TXE) == RESET)
    {
    }
    USART_SendData(UART4, data);
}

void UART4_SendString(const char *str)
{
    if(str == 0)
        return;

    while(*str != '\0')
    {
        UART4_SendByte((u8)*str);
        str++;
    }
}

void UART4_SendAngles(float pitch, float roll, float yaw)
{
    char tx_buffer[64];

    /* Frame example: 12.345:-1.200:90.000:\r\n */
    sprintf(tx_buffer, "%.3f:%.3f:%.3f:\r\n", pitch, roll, yaw);
    UART4_SendString(tx_buffer);
}

u16 UART4_ReadFrame(char *buffer, u16 buffer_size)
{
    u16 i = 0;

    if(buffer == 0 || buffer_size == 0 || UART4_RxFrameReady == 0)
        return 0;

    while(i < (u16)(buffer_size - 1) && UART4_RxFrame[i] != '\0')
    {
        buffer[i] = UART4_RxFrame[i];
        i++;
    }
    buffer[i] = '\0';

    UART4_RxFrameReady = 0;
    return i;
}

void UART4_IRQHandler(void)
{
    u8 data;

    if(USART_GetITStatus(UART4, USART_IT_RXNE) != RESET)
    {
        data = (u8)USART_ReceiveData(UART4);
        Usart4_Receive = data;

        UART4_HandleLegacyCommand(data);

        if(UART4_RxFrameReady == 0)
        {
            if(data == '\r' || data == '\n')
            {
                UART4_FinishRxFrame();
            }
            else
            {
                if(UART4_RxIndex < (UART4_RX_BUFFER_SIZE - 1))
                {
                    UART4_RxFrame[UART4_RxIndex++] = (char)data;

                    if(data == ':')
                    {
                        UART4_RxColonCount++;
                        if(UART4_RxColonCount >= 3)
                            UART4_FinishRxFrame();
                    }
                }
                else
                {
                    /* Overflow: discard the incomplete frame and restart. */
                    UART4_RxIndex = 0;
                    UART4_RxColonCount = 0;
                }
            }
        }
    }
}
